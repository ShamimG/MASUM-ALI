<?php

echo $GLOBALS['$num'];








?>